import dumbClassifiers
import datasets
import runClassifier
import knn
import perceptron
import dt